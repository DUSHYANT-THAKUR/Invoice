import React from "react";
import { jsPDF } from "jspdf";
import "./InvoiceZenvyFormat.css"; // Optional: Your custom styles (if needed)
import html2canvas from "html2canvas";
import zenvy from "./img1.jpeg";
import { Link, useLocation } from "react-router-dom";
import { FaMapMarkerAlt, FaTruck, FaCalendarAlt } from "react-icons/fa";
import axios from "axios";
import baseUrl from "../config/baseUrl";
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "800px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      <div
        id="invoice"
        style={{
          background: "#fff",
          padding: "10px",
          marginLeft: "5px",
          width: "110%",
        }}
      >
        <div className="invoice-page py-4">
          <div className="container">
            <div className="invoice-card bg-white p-4 p-md-5">
              <div className="d-flex justify-content-between">
                <div className="mb-5">
                  <h6 className="fw-semibold mb-1">
                    Company Name:
                    <span className="company-name">
                      OPEN BRACKET CLOUD SOLUTIONS PRIVATE LIMITED
                    </span>
                  </h6>
                  {/* <p className="mb-0 small">Phone No.: 7659345853</p> */}
                </div>
                <div>
                  <img src={zenvy} width={80} height={80} />
                  <p className="gst-num fw-bold mt-1">
                    GST No: 27AACCO3584C1ZJ
                  </p>
                </div>
              </div>

              <div className="invoice-header-strip mb-4">
                <div className="strip-purple"></div>
                <div className="strip-green text-center">
                  <h4 className="mb-0 fw-bold">E-Invoice</h4>
                </div>
              </div>

              <div className="row mb-4">
                <div className="col-md-4 mb-3 mb-md-0">
                  <h6 className="fw-semibold small mb-1">Bill To:</h6>
                  <p className="small mb-2">
                    <span>
                      {invoiceData.fullName
                        .split(" ")
                        .map(
                          (word) =>
                            word.charAt(0).toUpperCase() +
                            word.slice(1).toLowerCase()
                        )
                        .join(" ")}
                    </span>
                    <br />
                    <span>{invoiceData.billingAddress}</span>
                    <span>{invoiceData.city ? ", " : ""}</span>
                    <span>{invoiceData.city}</span>
                  </p>
                  <p className="small mb-0">
                    Contact No 📞: {invoiceData.mobileNo}
                  </p>
                </div>
                <div className="col-md-4 mb-3 mb-md-0">
                  <h6 className="fw-semibold small mb-1">Shipping To:</h6>
                  <p className="small mb-2">
                    <span>
                      {invoiceData.fullName
                        .split(" ")
                        .map(
                          (word) =>
                            word.charAt(0).toUpperCase() +
                            word.slice(1).toLowerCase()
                        )
                        .join(" ")}
                    </span>
                    <br />
                    <span>{invoiceData.billingAddress}</span>
                    <span>{invoiceData.city ? ", " : ""}</span>
                    <span>{invoiceData.city}</span>
                  </p>
                  <p className="small mb-0">
                    Contact No 📞: {invoiceData.mobileNo}
                  </p>
                </div>
                <div className="col-md-4">
                  <div className="d-flex flex-column gap-1">
                    <div>
                      <h6 className="fw-semibold small mb-1">Order Info:</h6>
                      <span className="fw-semibold small">
                        Order Id.: {invoiceData.orderNo}
                      </span>
                      <p className="p-0 m-0">
                        Order Date:{" "}
                        {invoiceData.transactionInvoiceCreatedOn.split(" ")[0]}
                      </p>
                      <p className="m-0 p-0">
                        Invoice Date:{" "}
                        {invoiceData.transactionInvoiceCreatedOn.split(" ")[0]}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Items Table */}
              <div className="table-responsive mb-3">
                <table className="table table-bordered invoice-table mb-0">
                  <thead>
                    <tr>
                      <th className="text-center small">Product</th>
                      <th className="text-center small">Qty</th>
                      <th className="text-center small">Price</th>
                      <th className="text-center small">Discount</th>
                      <th className="text-center small">Tax</th>
                      <th className="text-center small">GST</th>
                      <th className="text-center small">Platform fees</th>
                      <th className="text-center small">Total</th>

                      {/* <th className="text-center small">Total</th> */}
                    </tr>
                  </thead>
                  <tbody>
                    {/* {Array.from({ length: 5 }).map((_, idx) => ( */}
                    <tr className="item-empty-row">
                      <td>
                        {invoiceData.productName} <br />
                        <small style={{ color: "#666" }}>18% GST</small>
                      </td>
                      <td>1</td>
                      <td>₹{invoiceData.productPrice}</td>
                      <td>₹{invoiceData.discount}</td>
                      <td>₹{invoiceData.baseAmount}</td>
                      <td>₹{invoiceData.gst}</td>
                      <td>
                        ₹{invoiceData.shippingCharges}
                        <br />
                        <small>
                          (₹{parseFloat(invoiceData.shippingCharge1)} + ₹
                          {parseFloat(invoiceData.shippingCharge2)} GST)
                        </small>
                      </td>
                      <td>₹{invoiceData.paidAmount.toFixed(2)}</td>
                    </tr>
                    {/* ))} */}
                  </tbody>
                </table>
              </div>

              {/* Total row */}
              <div className="table-responsive mb-2">
                <table className="table table-bordered invoice-table-total mb-0">
                  <tbody>
                    <tr>
                      <td className="fw-semibold text-center">Total</td>
                      {/* <td style={{ width: "15%" }}></td>
                      <td style={{ width: "15%" }}></td> */}
                      <td style={{ width: "15%" }}>
                        ₹{invoiceData.paidAmount.toFixed(2)}{" "}
                      </td>
                    </tr>
                  </tbody>
                </table>
               <div className="p-2 text-secondary text-center">
                 <em >
                  This is a computer-generated invoice. No signature is
                  required.
                </em>
               </div>
              </div>

              {/* Amount in words + Summary */}
              <div className="row mb-4">
                <div className="col-md-12 mb-3 mb-md-0">
                  <div className="amount-words-box">
                    <div className="amount-words-title fw-semibold small">
                      Direct Deposite / Bank Wire Transfer:
                    </div>
                    <div className="amount-words-body small py-3 px-2">
                      Deposite the amount at Your nearest HDFC BANK in our
                      account in favour of OPEN BRACKET CLOUD SOLUTIONS PRIVATE
                      LIMITED.
                    </div>
                  </div>
                </div>
                {/* <div className="col-md-6">
                  <div className="summary-box small">
                    <div className="d-flex justify-content-between mb-1">
                      <span>Sub Total:</span>
                      <span>₹{invoiceData.productPrice}</span>
                    </div>
                     <div className="d-flex justify-content-between mb-1">
                      <span>Discount:</span>
                      <span>₹{invoiceData.discount}</span>
                    </div>
                    <div className="d-flex justify-content-between mb-1">
                      <span>GST</span>
                      <span>₹{invoiceData.gst}</span>
                    </div>
                    <div className="d-flex justify-content-between mb-1">
                      <span>Shipping charge:</span>
                      <span>₹{invoiceData.shippingCharges}</span>
                    </div>
                    <div className="d-flex justify-content-between mt-2 fw-semibold total-amount-line">
                      <span>Total Amount</span>
                      <span>₹{invoiceData.paidAmount.toFixed(2)}</span>
                    </div>
                  </div>
                </div> */}
              </div>

              {/* Terms & Conditions */}
              <div className="row mb-5">
                <div className="col-md-6">
                  <div className="terms-box small">
                    <div className="terms-title fw-semibold">
                      Transfer using account:
                    </div>
                    <div className="terms-body py-3 px-2">
                      <p className="p-0 m-0">Bank: HDFC BANK</p>
                      <p className="p-0 m-0">A/C No: 50200102880015</p>
                      <p className="p-0 m-0">IFSC Code : HDFC0000258</p>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <h6>Confirmation:</h6>
                  <p className="m-0 p-0">Send the payment confirmation to:</p>
                  <p className="m-0 p-0 text-success">
                    {" "}
                    OPENBRACKET4469@GMAIL.COM
                  </p>
                  <h6>Mor Info:</h6>
                  <p>
                    {" "}
                    Visit Our Website:
                    <span className="text-success"> https://zenvvy.co.in/</span>
                  </p>
                </div>
              </div>
              <p>
                OFFICE NO 1, NAJAF APARTMENT, Chapel Road, Bandra West, Mumbai
                Suburban, Maharashtra, 400050
              </p>
              {/* Seal & Signature */}
              {/* <div className="text-end small mt-5 pt-4">
                Seal &amp; Signature
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
function InvoiceZenvyFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation(); // Get the location object
  const { item, module } = location.state || {}; // Access the object passed via state
  // console.log("my itema and module is that",item,module)
  const downloadPDF = async () => {
    const input = document.getElementById("invoice"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save(`${item.orderNo}` + ".pdf"); // Save PDF
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
              // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceZenvyFormat;
