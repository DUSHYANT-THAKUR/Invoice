



// import React from "react";
// import { jsPDF } from "jspdf";
// // import "../InvoiceFormat/InvoiceFormat.css"; // Optional: Your custom styles (if needed)
// import html2canvas from "html2canvas";
// import '../InvoiceRishiKashiraFormat/invoice.css'
// import invoiceLogo from "./image.png";
// import { Link, useLocation } from "react-router-dom";
// import axios from "axios";
// import baseUrl from "../config/baseUrl";
// import logo from './image.png'; 
// const InvoiceDetails = ({ invoiceData }) => {
//   return (
//     <div
//       style={{
//         width: "855px",
//         marginLeft: "10px",
//         marginTop: "30px",
//         marginBottom: "30px",
//       }}
//     >
//       {/* <div id="invoice" style={{ background: "#fff", padding: "10px",marginLeft:"5px" }}></div> */}
//     <div className="invoice-container" id="invoice" style={{ background: "#fff", padding: "10px",marginLeft:"5px" }}>
//       <div className="invoice-header">
//         {/* <h1>🧾 Invoice Summary</h1> */}
//        <div style={{display:"flex"}}>
//          <img src={logo} width={180}/>
//         <p className='logo-text'>KASHIRALABS INDIA PVT LTD<br/><span>GST NO: 27AALCK5123G1ZJ</span></p>
        
//        </div>
//         <p>Order #: <strong>UH-474ad107a3f5a22d4a</strong></p>
//         {/* <p>Date: <strong>25-11-2025</strong></p> */}
//       </div>

//       <div className="section-grid-four">
//         <div className="section-box">
//           <h3> Order Info</h3>
//           <p><strong>ID:</strong> UH-474ad107a3f5a22d4a</p>
//           <p><strong>Order Date:</strong> 03-09-2025</p>
//           <p><strong>Invoice Date:</strong> 07-09-2025</p>
//         </div>

//         <div className="section-box">
//           <h3> Billing Details</h3>
//           <p><strong>Name:</strong> Raghu Kumar</p>
//           <p>New Mondha, Nanded</p>
//           <p>431601<br /> • 📞 7010312440</p>
//         </div>

//         <div className="section-box">
//           <h3> Shipping Details</h3>
//           <p><strong>Name:</strong>  Raghu Kumar</p>
//           <p>New Mondha, Nanded</p>
//           <p>431601<br /> • 📞 7010312440</p>
//         </div>

//         <div className="section-box">
//           <h3>Payment Details</h3>
//           <p><strong>Payment Method:</strong> UPI</p>
//           {/* <p><strong>Transaction ID:</strong> rzp_test_Bd2Xe7zK4jdmIh</p> */}
//           <p><strong>Amount:</strong> ₹2697.65</p>
//         </div>
//       </div>

//       <div className="section-box product-summary">
//         <h3> Product Summary</h3>
//         <table className="product-table">
//           <thead>
//             <tr>
//               <th>Product</th>
//               <th>Qty</th>
//               <th>Price</th>
//               <th>Discount</th>
//               <th>Taxable</th>
//               <th>GST</th>
//               <th>Shipping</th>
//               <th>Total</th>
//             </tr>
//           </thead>
//           <tbody>
//             <tr>
//               <td>
//                 Social Media Marketing<br />
//                 <small style={{ color: "#666" }}>18% GST</small>
//               </td>
//               <td>1</td>
//               <td>₹2800.00</td>
//               <td style={{ color: "red" }}>₹558</td>
//               <td>₹2242</td>
//               <td>₹403.56</td>
//               <td>₹52.09<br /><small>(₹42.79 + ₹9.30 GST)</small></td>
//               <td><strong>₹2697.65</strong></td>
//             </tr>
//           </tbody>
//         </table>
//       </div>

//       <div className="section-box total-summary">
//         <h3> Summary</h3>
//         <p><strong>Subtotal:</strong> ₹2800.00</p>
//         <p><strong>Shipping:</strong> ₹52.09</p>
//         <p><strong>Discount:</strong> ₹558</p>
//         <p><strong>GST:</strong> ₹403.56</p>
//         <p><strong>Total:</strong> ₹2697.65</p>
//       </div>

//       {/* <div className="footer-note">
//         Thank you for shopping with us! 🧡
//       </div> */}

//       {/* Bank and company details section */}
//       <div className="section-box bank-details" style={{ marginTop: "2rem", fontSize: "14px", lineHeight: "1.6" }}>
//         <p style={{ fontStyle: "italic", textAlign: "center" }}>This is a computer-generated invoice. No signature is required.</p>

//         <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", marginTop: "1rem" }}>
//           <div style={{ flex: "1", minWidth: "250px" }}>
//             <h4 style={{ color: "#1a237e" }}>Direct Deposit / Bank Wire Transfer:</h4>
//             <p>Deposit the amount at your nearest<br />
//               <strong>JANA SMALL FINANCE BANK</strong><br />
//               in our accounts in favour of<br />
//               <strong>KASHIRALABS INDIA PVT LTD.</strong>
//             </p>
//           </div>

//           <div style={{ flex: "1", minWidth: "250px" }}>
//             <h4 style={{ color: "#1a237e" }}>Confirmation:</h4>
//             <p>Send the payment confirmation<br />
//               to: <a href="mailto:rsshoba0567@gmail.com">rsshoba0567@gmail.com</a>
//             </p>

//             <h4 style={{ color: "#1a237e" }}>More Info:</h4>
//             <p>Visit our website: <a href="https://xuwi.co.in" target="_blank" rel="noopener noreferrer">https://xuwi.co.in</a></p>
//           </div>
//         </div>
//           <div>
//             <h4 style={{ color: "#1a237e" }}>Transfer Using Account:</h4>
//             <p style={{fontWeight:600}}>Jana Small Finance Bank A/C No:759020001219416
//             </p>
//             <p style={{fontWeight:600}}>IFSC-JSFB000759</p>
//           </div>

//         <p style={{ textAlign: "center", marginTop: "1.5rem" }}>
//           <strong>
//             2ND FLOOR SHOP-79 B WING,EXPRESS ZONE MALL W EXPRESS HIGHWAY PATEL VANILLA GUREGAON (E) Mumbai, Mumbai Suburban Maharashtra, 400063
//           </strong>
//         </p>
//       </div>
//     </div>
//     </div>
//   );
// };
// function InvoiceRishiFormat() {
//   const auth = localStorage.getItem("user");
//   const location = useLocation(); // Get the location object
//   const { item, module } = location.state || {}; // Access the object passed via state
//   const downloadPDF = async () => {
//     const input = document.getElementById("invoice"); // Select the invoice container
//     const formData = new FormData();
//     formData.append("orderNo", item.orderNo);
//     html2canvas(input).then((canvas) => {
//       const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
//       const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
//       const pdfWidth = pdf.internal.pageSize.getWidth();
//       const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

//       pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
//       pdf.save(`UH-474ad107a3f5a22d4a` + ".pdf"); // Save PDF
//     });
//     const config = {
//       headers: {
//         "Content-type": "application/json",
//         Accept: "application/json",
//         Authorization: `Bearer ${auth}`,
//       },
//     };
//     if (module !== "/Invoice/Downloaded") {
//       await axios.post(
//         `${baseUrl}/changeStatusDownloadedInvoice`,
//         formData,
//         config
//       );
//     }
//   };
//   return (
//     <div>
//       <div className="row m-0 p-0">
//         <div className="col-6">
//           <Link to={`${module}`}>
//             <button
//               style={{
//                 backgroundColor: "#ff9707",
//                 color: "#fff",
//                 width: "80px",
//                 border: "none",
//                 borderRadius: "5px",
//                 cursor: "pointer",
//                 fontSize: "16px",
//                 marginTop: "20px",
//                 padding: "4px 5px",
//               }}
//               // onClick={downloadPDF}
//             >
//               Back
//             </button>
//           </Link>
//         </div>
//         <div className="col-5 offset-1">
//           <button
//             style={{
//               backgroundColor: "#ff9707",
//               color: "#fff",
//               border: "none",
//               borderRadius: "5px",
//               cursor: "pointer",
//               fontSize: "16px",
//               marginTop: "20px",
//               width: "80px",
//               padding: "4px 5px",
//             }}
//             onClick={downloadPDF}
//           >
//             Download
//           </button>
//         </div>
//       </div>
//       <InvoiceDetails invoiceData={item} />
//     </div>
//   );
// }
// export default InvoiceRishiFormat;



import React from "react";
import { jsPDF } from "jspdf";
// import "../InvoiceFormat/InvoiceFormat.css"; // Optional: Your custom styles (if needed)
import html2canvas from "html2canvas";
import '../InvoiceRishiKashiraFormat/invoice.css'
import invoiceLogo from "./image.png";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import baseUrl from "../config/baseUrl";
import logo from './image.png'; 
const InvoiceDetails = ({ invoiceData }) => {
  return (
    <div
      style={{
        width: "855px",
        marginLeft: "10px",
        marginTop: "30px",
        marginBottom: "30px",
      }}
    >
      {/* <div id="invoice" style={{ background: "#fff", padding: "10px",marginLeft:"5px" }}></div> */}
 <div  id="invoice" className="invoice-container" style={{ background: "#fff", padding: "10px",marginLeft:"5px" }}>
      <div className="invoice-header">
        {/* <h1>🧾 Invoice Summary</h1> */}
       <div style={{display:"flex"}}>
         <img src={logo} width={180}/>
        <p className='logo-text'>KASHIRALABS INDIA PVT LTD<br/><span>GST NO: 27AALCK5123G1ZJ</span></p>
        
       </div>
       <div>
       <strong className="text-dark">Order #:</strong>{invoiceData.orderNo}
       </div>
        {/* <p>Order #: <strong>UH-474ad107a3f5a22d4a</strong></p> */}
        {/* <p>Date: <strong>20-11-2025</strong></p> */}
      </div>

      <div className="section-grid-four">
        <div className="section-box">
          <h3> Order Info</h3>
          <div>
          <strong className="text-dark">Order ID:</strong>{invoiceData.orderNo}
          </div>
          {/* <p><strong>ID:</strong>UH-474ad107a3f5a22d4a</p> */}
          <div>
          <strong className="text-dark">Order Date:</strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
          </div>
          {/* <p><strong>Order Date:</strong> 03-09-2025</p> */}
          <div>
          <strong className="text-dark">Invoice Date:</strong>{invoiceData.transactionInvoiceCreatedOn.split(' ')[0]}
          </div>
          {/* <p><strong>Invoice Date:</strong> 14-11-2025</p> */}
        </div>

        <div className="section-box">
          <h3> Billing Details</h3>
          <p><strong>Name: </strong>{invoiceData.fullName
                  .split(" ")
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(" ")}</p>
           <span>{invoiceData.billingAddress}{invoiceData.city ? ", " : ""}</span>
          <span>{invoiceData.city}</span>
          <p>Phone📞: {invoiceData.mobileNo}</p>
        </div>

        <div className="section-box">
          <h3> Shipping Details</h3>
          <p><strong>Name: </strong>{invoiceData.fullName
                  .split(" ")
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(" ")}</p>
          <span>{invoiceData.billingAddress}{invoiceData.city ? ", " : ""}</span>
          <span>{invoiceData.city}</span>
          <p>Phone📞: {invoiceData.mobileNo}</p>
        </div>

        <div className="section-box">
          <h3>Payment Details</h3>
          <p><strong>Payment Method:</strong> UPI</p>
          {/* <p><strong>Transaction ID:</strong> BIC17</p> */}
          <p><strong>Amount:</strong> ₹{invoiceData.paidAmount}</p>
        </div>
      </div>

      <div className="section-box product-summary">
        <h3> Product Summary</h3>
        <table className="product-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Qty</th>
              <th>Price</th>
              <th>Discount</th>
              <th>Taxable</th>
              <th>GST</th>
              <th>Platform Fees</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                {invoiceData.productName}<br />
                <small style={{ color: "#666" }}>18% GST</small>
              </td>
              <td>1</td>
              <td>₹{invoiceData.productPrice}</td>
              <td style={{ color: "red" }}>₹{invoiceData.discount}</td>
              <td>{invoiceData.baseAmount}</td> 
              <td>{invoiceData.gst}</td>
              <td>{invoiceData.shippingCharges}<br /><small>({parseFloat(invoiceData.shippingCharge1)} + {parseFloat(invoiceData.shippingCharge2)} GST)</small></td>
              <td><strong>{invoiceData.paidAmount.toFixed(2)}</strong></td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="section-box total-summary">
        <h3> Summary</h3>
        <p><strong>Subtotal:</strong>₹{invoiceData.productPrice}</p>
        <p><strong>Platform Fees:</strong> ₹{invoiceData.shippingCharges}</p>
        <p><strong>Discount:</strong> ₹{invoiceData.discount}</p>
        <p><strong>GST:</strong> ₹{invoiceData.gst}</p>
        <p><strong>Total:</strong> ₹{invoiceData.paidAmount.toFixed(2)}</p>
      </div>

      {/* <div className="footer-note">
        Thank you for shopping with us! 🧡
      </div> */}

      {/* Bank and company details section */}
      <div className="section-box bank-details" style={{ fontSize: "14px", lineHeight: "1.6" }}>
        <p style={{ fontStyle: "italic", textAlign: "center" }}>This is a computer-generated invoice. No signature is required.</p>

        <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", marginTop: "1rem" }}>
          <div style={{ flex: "1", minWidth: "250px" }}>
            <h5 style={{ color: "#1a237e" }}>Direct Deposit / Bank Wire Transfer:</h5>
            <p>Deposit the amount at your nearest<br />
              <strong>JANA SMALL FINANCE BANK</strong><br />
              in our accounts in favour of<br />
              <strong>KASHIRALABS INDIA PVT LTD.</strong>
            </p>
          </div>

          <div style={{ flex: "1", minWidth: "250px" }}>
            <h5 style={{ color: "#1a237e" }}>Confirmation:</h5>
            <p>Send the payment confirmation<br />
              to: <a href="mailto:rsshoba0567@gmail.com">rsshoba0567@gmail.com</a>
            </p>

            <h4 style={{ color: "#1a237e" }}>More Info:</h4>
            <p>Visit our website: <a href="https://xuwi.co.in" target="_blank" rel="noopener noreferrer">https://xuwi.co.in</a></p>
          </div>
        </div>
          <div>
            <h4 style={{ color: "#1a237e" }}>Transfer Using Account:</h4>
            <p style={{fontWeight:600}}>Jana Small Finance Bank A/C No:759020001219416
            </p>
            <p style={{fontWeight:600}}>IFSC-JSFB000759</p>
          </div>

        <p style={{ textAlign: "center", marginTop: "1rem" }}>
          <strong>
            2ND FLOOR SHOP-79 B WING,EXPRESS ZONE MALL W EXPRESS HIGHWAY PATEL VANILLA GOREGAON (E) Mumbai, Mumbai Suburban Maharashtra, 400063
          </strong>
        </p>
      </div>
    </div>
    </div>
  );
};
function InvoiceRishiFormat() {
  const auth = localStorage.getItem("user");
  const location = useLocation(); // Get the location object
  const { item, module } = location.state || {}; // Access the object passed via state
  const downloadPDF = async () => {
    const input = document.getElementById("invoice"); // Select the invoice container
    const formData = new FormData();
    formData.append("orderNo", item.orderNo);
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/JPEG"); // Convert canvas to image
      const pdf = new jsPDF("p", "mm", "a4"); // Create a jsPDF document
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "JPEG", 0, 0, pdfWidth, pdfHeight); // Add image to PDF
      pdf.save(`${item.orderNo}` + ".pdf"); // Save PDF
    });
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
        Authorization: `Bearer ${auth}`,
      },
    };
    if (module !== "/Invoice/Downloaded") {
      await axios.post(
        `${baseUrl}/changeStatusDownloadedInvoice`,
        formData,
        config
      );
    }
  };
  return (
    <div>
      <div className="row m-0 p-0">
        <div className="col-6">
          <Link to={`${module}`}>
            <button
              style={{
                backgroundColor: "#ff9707",
                color: "#fff",
                width: "80px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
                fontSize: "16px",
                marginTop: "20px",
                padding: "4px 5px",
              }}
              // onClick={downloadPDF}
            >
              Back
            </button>
          </Link>
        </div>
        <div className="col-5 offset-1">
          <button
            style={{
              backgroundColor: "#ff9707",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer",
              fontSize: "16px",
              marginTop: "20px",
              width: "80px",
              padding: "4px 5px",
            }}
            onClick={downloadPDF}
          >
            Download
          </button>
        </div>
      </div>
      <InvoiceDetails invoiceData={item} />
    </div>
  );
}
export default InvoiceRishiFormat;





