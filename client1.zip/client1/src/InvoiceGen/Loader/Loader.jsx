// Loader.js
import React from "react";
import "./Loader.css"; // You will need to create this CSS file for styling

const Loader = () => {
  return (
    <div className="loader-container">
      <div className="loader"></div>
    </div>
  );
};

export default Loader;
